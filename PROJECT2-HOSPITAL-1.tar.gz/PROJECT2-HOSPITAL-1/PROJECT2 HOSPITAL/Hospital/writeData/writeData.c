
/*
 *
 *
 *
 *
 *
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "../MAIN/hospital.h"

#define DATABASE "DATABASE.dat"

void removeNewline(char *input)
    {
    if(input[strlen(input)-1]=='\n')
        {
        input[strlen(input)-1]='\0';
        }
    }

void readBuffer(char *buffer, PATIENT_T *patient)
	{
	char *token = NULL;
	int count = 0;
	
	token = strtok(buffer, "[]");
	while(token != NULL)
        {
		if(strcmp(token, " ") != 0)
			{
			if(count==0)
				strcpy(patient->recordNum, token);
            else if(count==1)
                strcpy(patient->name, token);
            else if(count==2)
                strcpy(patient->birthDate, token);
            else if(count==3)
                sscanf(token, "%c", &patient->gender);
            else if(count==4)
                strcpy(patient->nationality, token);
            else if(count==5)
                strcpy(patient->passport, token);
            else if(count==6)
                strcpy(patient->phoneNum, token);
            else if(count==7)
                strcpy(patient->address, token);
            else if(count==8)
                strcpy(patient->admissionDate, token);
			else if(count==9)
                strcpy(patient->releaseDate, token);
			count++;
			}
		token = strtok(NULL, "[]");
		}
	}

void writeDatabase(PATIENT_T *patient,int *header)
    {
    FILE *pOutfile = NULL; 
    pOutfile = fopen(DATABASE, "wb");
    if(pOutfile == NULL)
        {
        printf("Some error occur in openning file!\n");
        exit(1);
        }
    /* write file informations */
    else if(fwrite(header, sizeof(int), 2, pOutfile) != 2)
        {
        printf("Some error occur in writting data!\n");
        exit(2);
        }
    /* write all data */  
    else if(fwrite(patient, sizeof(PATIENT_T), header[0], pOutfile) != header[0])
        {
        printf("Some error occur in writting data!\n");
        exit(3);
        }
    fclose(pOutfile);
    }

int main()
	{
	char buffer[4096];
	int header[2] = {0,0};
	int count = 0;
	PATIENT_T *patient = NULL;
	FILE *pInfile = NULL;

	pInfile = fopen("../DUMPFILE.txt", "r");
    if(pInfile == NULL)
        {
        printf("Cannot open the file!\n");
        exit (1);
        }

	if(fgets(buffer, sizeof(buffer), pInfile) != NULL)
        {
        sscanf(buffer, "%d %d", &header[0], &header[1]);
        /* allocate memories for hold each data */
        patient = (PATIENT_T*) calloc(header[1], sizeof(PATIENT_T));
        /* if can't reserve memories display error and exit */
        if(patient == NULL)
            {
            printf("Cannot allocate memories\n");
            exit(2);
            }
        }
	/* get all data */
	while(fgets(buffer,sizeof(buffer),pInfile) != NULL)
        {
		removeNewline(buffer);
        readBuffer(buffer, (patient+count));
        printf("[%s] [%s] [%s] [%c] [%s] [%s] [%s] [%s] [%s] [%s]\n", (patient+count)->recordNum, (patient+count)->name, (patient+count)->birthDate, (patient+count)->gender, (patient+count)->nationality, (patient+count)->passport, (patient+count)->phoneNum, (patient+count)->address, (patient+count)->admissionDate, (patient+count)->releaseDate);
        count++;
        }
	fclose(pInfile);
	writeDatabase(patient, header);

	return 0;
	}
