/***************************************************************
 *
 * searchData.c
 *
 * This header file declares function for searchData.c
 *
 * Created by Woraphop Kootranunt ID : 57070503430
 * 3 December 2014
 *
 ***************************************************************
 */

/*
 * searchEach
 * This function will search each data by type of search
 * then ask user for editing or deleting
 * Argument:
 *      patient - data of patient
 *      header - number of data
 *      choice - choice of search type
 *      search - data to search
 */
void searchEach(PATIENT_T *patient, int *header, int choice, char *search);

/*
 * searchData
 * This function will show search menu then get data search
 * Argument :
 *      patient - data of patient
 *      header - number of data
 */
void searchData(PATIENT_T *patient, int *header);
