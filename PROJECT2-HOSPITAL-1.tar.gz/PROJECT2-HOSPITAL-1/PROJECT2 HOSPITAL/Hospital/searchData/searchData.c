/***************************************************************
 *
 * searchData.c
 *
 * This program will search the data from database
 * then ask user they want to modify that data or not.
 *
 * Created by Woraphop Kootranunt ID : 57070503430
 * 3 December 2014
 *
 ***************************************************************
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "../MAIN/hospital.h"
#include "../displayData/displayData.h"
#include "../validFunction/validFunction.h"
#include "../modifyData/modifyData.h"
#include "../deleteData/deleteData.h"
#include "searchData.h"

/*
 * searchEach
 * This function will search each data by type of search
 * then ask user for editing or deleting
 * Argument:
 *      patient - data of patient
 *      header - number of data
 *      choice - choice of search type
 *      search - data to search
 */
void searchEach(PATIENT_T *patient, int *header, int choice, char *search)
	{
	int count = 0; /* number of found data */
	int i = 0; /* index */
	int *position; /* to store position of data that found */
	int checkName = 0; /* to check address between data in database and data search */
	int which = 0; /* to get which file user want to see */
	char tmpName[MAXBUFFER]; /* to hold temporary name of data */
	char input[MAXBUFFER]; /* buffer */

    /* allocate enough memory to hold position of data */
	position = (int*) calloc(header[0], sizeof(int));

	for(i=0; i < header[0]; i++)
        {
        /* search from the medical record number then display result */
        if(choice == 1 && strcmp((patient+i)->recordNum, search) == 0)
            {
			count++;
			printf("RECORD#%d : %s\n", count, (patient+i)->recordNum);
			position[count] = i;
            }
        /* search from the name then display result */
		else if(choice == 2)
            {
			strcpy(tmpName, (patient+i)->name);
			/* call function to make string to lowercase */
			tolowercase(tmpName, sizeof(tmpName));
			tolowercase(search, sizeof(search));
			if(strstr(tmpName, search) != NULL)
				{
				checkName = strstr(tmpName, search) - tmpName;
				if(checkName == 0)
					{
            		count++;
					printf("RECORD#%d : %s\n", count, (patient+i)->name);
					position[count] = i;
					}
				else if(tmpName[checkName-1] == ' ')
					{
					count++;
					printf("RECORD#%d : %s\n", count, (patient+i)->name);
					position[count] = i;
					}
				}
            }
        /* search from the admission date then display result */
		else if(choice == 3 && strcmp((patient+i)->admissionDate, search) == 0)
            {
            count++;
			printf("RECORD#%d : %s\n", count, (patient+i)->admissionDate);
			position[count] = i;
            }
		}
    /* show how many data was found */
	printf("==== %d RECORD(s) FOUND.\n", count);

	if(count > 0)
        {
        /* ask user which data user want to display */
		do
		    {
			memset(input, 0, sizeof(input));
			printf("==== WHICH RECORD DO YOU WANT TO SEE: ");
		    fgets(input,sizeof(input),stdin);
			}while(atoi(input) < 1 || atoi(input) > count || isdigit(input[0]) == 0);
			sscanf(input, "%d", &which);
		displayEach(patient, position[which]);
        /* ask what user want to do with the data */
		do
		    {
			memset(input, 0, sizeof(input));
			printf("==== WHAT DO YOU WANT TO DO NEXT?\n");
			printf("==== 1 - Edit\n");
			printf("==== 2 - Delete\n");
			printf("==== 3 - Exit\n");
			printf("= ENTER YOUR CHOICE: ");
		    fgets(input, sizeof(input), stdin);
			}while(atoi(input) < 1 || atoi(input) > 3 || isdigit(input[0]) == 0);

        /* modify data */
		if(input[0] == '1')
			{
            /* call function to modify data */
			modifyData(patient, header, position[which]);
			}
        /* delete data */
		else if(input[0] == '2')
			{
			do
				{
				printf("= Do you want to delete this data? (y/n): ");
				fgets(input,sizeof(input),stdin);
				removeNewline(input);
				input[0] = tolower(input[0]);
				}while(strlen(input) != 1 || (input[0] != 'y' && input[0] !='n'));
			if(input[0] == 'y')
				{
                /* call function to delete data */
				deleteData(patient, header, position[which]);
				}
			}
        }
	}


/*
 * searchData
 * This function will show search menu then get data search
 * Argument :
 *      patient - data of patient
 *      header - number of data
 */
void searchData(PATIENT_T *patient, int *header)
	{
	char input[MAXBUFFER]; /* buffer */
	char search[MAXBUFFER]; /* data to search */
	int choice = 0; /* to store choice from user */
	int result = 0; /* to receive return value from function check format */
    /* clear screen */
	printf("\e[1;1H\e[2J");
	do
        {
		memset(input, 0, sizeof(input));
        printf("=======================================================\n");
        printf("==================== Search Menu ======================\n");
        printf("=======================================================\n");
        printf("====	1 - Search by Medical record number        ====\n");
        printf("====	2 - Search by Name                         ====\n");
        printf("====	3 - Search by Most recent admission date   ====\n");
        printf("====	0 - Exit                                   ====\n");
        printf("=======================================================\n");
        printf("= Enter your choice: ");
		memset(input, 0, sizeof(input));
        fgets(input, sizeof(input), stdin);
        }while(atoi(input) < 0 || atoi(input) > 7 || isdigit(input[0]) == 0);
	sscanf(input, "%d", &choice);
	memset(search, 0, sizeof(search));
    /* search from the medical record number */
	if(choice == 1)
		{
		do
			{
			printf("\nEnter medical record number of patient (yyyy-nnnnn): ");
			fgets(input, sizeof(input), stdin);
			removeNewline(input);
			result = checkRecordNumber(input, patient, header);
			}while(result != 1);
		strcpy(search, input);
		}
    /* search from the name */
	else if(choice == 2)
		{
		getName(input);
		strcpy(search, input);
		}
	/* search from the admission date */
	else if(choice == 3)
		{
		do
			{
			printf("\nEnter most recent admission date (dd/mm/yyyy): ");
			fgets(input, sizeof(input), stdin);
			removeNewline(input);
			result = checkDate(input);
			}while(result != 1);
		strcpy(search, input);
		}
    /* search and show result */
	if(choice>0 && choice<=3)
        {
        searchEach(patient, header, choice, search);
        }
	}
