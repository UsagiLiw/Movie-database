/************************************************
 *
 * validFunction.c
 *
 * This program will validate input form user.
 *
 *  Created by Thanchanok Eiamsakulchai ID : 57070503416
 *              Woraphop Kootranunt ID : 57070503430
 *              Nattawut Promsin ID : 57070503413
 *              Wasunan Rojkanok ID : 57070503432
 *              Karn Watthanatraiphob ID : 57070503402
 *  2 December 2014
 *
 ************************************************/

/* Define a structure type to hold date information */
typedef struct
{
    int year;    /* C.E. year */
    int month;   /* month, from 1 to 12 */
    int day;     /* day, from 1 to a max of 31 */ 
} DATE_T;

/* This function will remove newline from the buffer. */
void removeNewline(char *input);
/* this function will check name form. If input is invalid form 
   it will return by correct varaible */
int checkName(char name[]);
/* this function will check that is the input correct 
	and match nationality abbreviate or not */
int checkNationality(char *input);
/* this function will check that is input correct or not
   if nationality is "TH", must be 13 digits. Otherwise, can be from 8 to 16 digits.	 */
int checkPassport(char* passportId,char* nationality);
/* this function will check if input is correct or not
   Just M F OR N (UPPERCASE CHARATER) */
int checkGender(char input[]);
/* this function will check if input date is correct or not
   correct format is DD/MM/YYYY BE. */ 
int checkDate(char * inputDate);
/* this function will collect date from local time */
void dateToday(char* today);
/* Compares two DATE_T structures. */
int dateCompare(char firstDate[],char secondDate[]);
/* this funtion will ask user a patient's gender
   if the input is invalid it will ask again */
void getGender(char * gender);
/* this function will ask user a patient's name
   and if the name format is invalid it will ask again */
void getName(char* name);
/* this function will ask user a patient's birthday
   if a birthday is in invalid format or in future 
   the program will print error message ask again */
void getBirthDate(char* birthDate); 
/*  this function will ask user a most recently patient's admission date
 *		if admission date is in invalid format or in future
 *		the program will print error message ask again  */
void getAdmissionDate(char* admissDate,char* birthDate);
/*      this function will ask user a most recently patient's release date
 *		if release date is in invalid format or in future
 *		the program will print error message ask again*/
void getReleaseDate(char* releaseDate,char* admissDate);
/*      this function will ask user a patient's nationality
 *		if nationality is do not match any abbreviate nationality
 *		it will print error message and ask again */
void getNationality(char* nationality);
/* this function will ask user a patent's passport ID
 * if passport ID is in wrong format it will ask user again */
void getPassportId(char* passportID,char* nationality);
/* this function will ask user a patient's home address
 *	if home adress be blank , a program will ask again  */
void getHomeAddress(char* address);
/*  this function will ask user a patient's phone number
 *  this function will check  for mat of phone number (+aaa-bbbbbb-ccccccc)
 *	if it is not in correct format, program will print error message */
void getTeleNum(char * phoneNumber);
/* This function will check medical record number format. */
int checkRecordNumber(char *input, PATIENT_T *patient, int *header);


/*
 *	tolowercase Function
 *	Argument :
 *		- input- string to change to lowercase
 *		- size- sizeof that string
 */
void tolowercase(char *input, int size);
