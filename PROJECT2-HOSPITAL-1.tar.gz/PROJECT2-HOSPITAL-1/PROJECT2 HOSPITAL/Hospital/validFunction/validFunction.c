/************************************************
 *
 * validFunction.c
 *
 * This program will validate input form user.
 *
 *  Created by Thanchanok Eiamsakulchai ID : 57070503416
 *              Woraphop Kootranunt ID : 57070503430
 *              Nattawut Promsin ID : 57070503413
 *              Wasunan Rojkanok ID : 57070503432
 *              Karn Watthanatraiphob ID : 57070503402
 *  2 December 2014
 *
 ************************************************/



#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <time.h>

#include "../MAIN/hospital.h"
#include "../searchData/searchData.h"
#include "validFunction.h"


/*
 *	removeNewline function
 *	This function will remove newline from the buffer.
 *	Argument : 
 *		- input - buffer string
 *
 */
void removeNewline(char *input)
{
	if(input[strlen(input) - 1] == '\n')
			{
			input[strlen(input) - 1] = '\0';	
			}
}

/*
 *     checkName function
 *     this function will check name form. If input is invalid form 
 *     it will return by correct varaible
 *	   Argument : 
 *	   - name : get input to check name form
 *     Return : correct
 *	   0 -> valid
 *     1 -> invalid
 */
int checkName(char name[])
{
	int i = 0; /* count loop */
	int correct = 0; /* return value is it correct or not */
	int next = 0;  /* if input doesn't match first condition go to check second condition */

	
	removeNewline(name);
	if(strlen(name) < 1) /* if name is blank */
		{
		next = 1; /* set next to 1 so do not have to check second condition */
		correct = 1; 
		}
	else if(next == 0)
		{
		for(i = 0; i < strlen(name); i++)
			{
			if(!(isalpha(name[i]) || name[i] == '.' || name[i] == '\"' || name[i] == '\'' || isspace(name[i])))
				{
				printf("\nINVALID NAME -- ONLY ALPHABEHT(A-Z), APOSTROPHE('), AND PERIOD(.) ARE ALLOWED\n");
				correct = 1;
				i = strlen(name);
				}
			else
				{
				correct = 0;
				}
			}
		}

return correct;
}

/*	
 *		checkNationality function
 *	    this function will check that is the input correct 
 *		and match nationality abbreviate or not
 *		Argument :		
 *		- input : get nationality
 *		return :
 *		0 -> INVALID 
 *		1 -> VALID
 *
 */
int checkNationality(char *input)
    {
    char tempNationality[] = {"AF,AL,DZ,AD,AO,AI,AR,AM,AU,AT,AZ,BH,BY,BE,BJ,BO,BA,BR,AX,AS,AI,AQ,AG,AW,BS,BD,BB,BZ,BJ,BM,BT,BO,BQ,BA,BW,BV,IO,BN,BG,BF,I,KH,CM,CA,CV,KY,CF,TD,CL,CN,CX,CC,CO,KM,CG,CD,CK,CR,CI,HR,CU,CW,CY,CZ,DK,DJ,DM,DO,EC,EG,SV,GQ,ER,EE,ET,FK,FO,FJ,FI,FR,GF,TF,PF,GA,GM,GE,DE,GH,GI,GR,GL,GD,GP,GU,GT,GG,GN,GW,GY,HT,HM,VA,HN,HK,HU,IS,IN,ID,IR,IQ,IM,IE,I,IT,JM,JP,JE,JO,KZ,KE,KI,KP,KR,KW,KG,LA,LV,LB,LS,LR,LY,LI,LT,LU,MO,MK,MG,MW,MY,MV,ML,MT,MH,MQ,MR,MU,YT,MX,FM,MD,MC,MN,ME,MS,MA,MZ,MM,NA,NR,NP,NL,NC,NZ,NI,NE,NG,NU,NF,MP,NO,OM,PK,PW,PS,PA,PG,PY,PE,PH,PN,PL,PT,PR,QA,RE,RO,RU,RW,BL,SH,KN,LC,MF,PM,VC,WS,SM,ST,SA,SN,RS,SC,SL,SG,SX,SK,SI,SB,SO,ZA,GS,SS,ES,LK,SD,SR,ES,LK,SD,SR,SJ,SZ,SE,CH,SY,TW,TJ,TZ,TH,TL,TG,TK,TO,TT,TN,TR,TM,TC,TV,UG,UA,AE,GB,US,UM,UY,UZ,VU,VE,VN,VG,VI,WF,EH,YE,ZM,ZW"};
   	

   	removeNewline(input);
	if(strlen(input) == 0)
   	{
   		return 0;
   	}
    else if(strstr(tempNationality, input) != NULL) /* check if input match any string in tempNationality variable */
    {
    	if(strcmp(input, ",") == 0) /* if match ',' It is invalid */
    	{
			printf("--- INVALID FORM ");
    		return 0;
    	}
        return 1;
    }

    
    return 0;
    }

/*
 *		checkPassport function
 *		this function will check that is input correct or not
 *		if nationality is "TH", must be 13 digits. Otherwise, can be from 8 to 16 digits.		
 *		Argument : 
 *		passportId : get input to check passport ID format	
 *		nationality : to check if nationality is TH or not
 *		Return : correct
 *		0 -> valid
 *		1 -> invalid
 *
 */

int checkPassport(char* passportId,char* nationality)
{
	int correct = 0; /* return value is it correct or not */
	int next = 0; /* if input doesn't match first condition go to check second condition */
	int i = 0; /* count loop */
	removeNewline(passportId);
	
	for(i = 0 ; i < strlen(passportId) ; i++)
	{
	if(!isdigit(passportId[i])) /* check if it is digit or not */
		{
		correct = 1; /* invalid set correct to be 1 */
		next = 1; /* set next to 1 do not have to check next condition */
		}
	}
	if(next == 1) 
	{
		printf("--- INVALID INPUT -- ONLY NUMERIC INPUT\n");
	}

	if(next == 0) 
	{
		if(strcmp(nationality,"TH") == 0) /* TH nationality -- 13 digits */
			{
			if(strlen(passportId) != 13)
				{
				printf("--- INVALID INPUT -- PASSPORT ID MUST HAVE 13 CHARACTERS\n");
				correct = 1;
				}
			else
				{
				correct = 0;
				}
			}
		else /* other nationality -- 8-16 digits */
			{
			if(strlen(passportId) < 8 || strlen(passportId) > 16)
				{
				correct = 1;
				}
			}
	}
	return correct;
}

/*		
 *		checkGender function
 *		this function will check if input is correct or not
 *		Just M F OR N (UPPERCASE CHARATER)
 *		Argument :
 *		input : get input to chek gender
 *		Return : gender
 *		0 -> Invalid
 *		1 -> Male
 *		2 -> Female
 *		3 -> Not specified
 */

int checkGender(char input[])
{

	int gender = 0; /* return value is it correct or not */
	

 			if(strcmp(input,"M") == 0)
 				{	 
 				gender = 1;
 				}
	 		else if(strcmp(input,"F") == 0)
	 			{
				gender = 2;
	 			}
	 		else if(strcmp(input,"N") == 0)
	 			{
	 			gender = 3;
	 			}
	 		else
	 			{
	 			gender = 0;
	 			}

return gender;
}
/*
 *		checkDate function
 *		this function will check if input date is correct or not
 *		correct format is DD/MM/YYYY BE. 
 *		this function will check leap year too
 *		Argument : 
 *		inputDate : get input to check date
 *		Return : bStop
 *		0 -> invalid
 *		1 -> valid
 *
 */
int checkDate(char * inputDate)
{
	int tempDay = 0; /* to collect day that divided from inputDate */
	int tempMonth = 0; /* to collect month that divided from inputDate */
	int tempYear = 0; /* to collect year that divided from inputDate */
	int bStop = 1; /* return value is it correct format or not */
	int monthDays[12] = {31,28,31,30,31,30,31,31,30,31,30,31}; /* to check max days in each month */
	int maxDay = 0; /* max day in each month */
	int i = 0; /* count loop */


	removeNewline(inputDate);
	if(strlen(inputDate) != 10) /* if date length is not 10 -- INVALID */
		{
		printf("--- INVALID FORMAT -- DD/MM/YYYY\n");
		bStop = 0;
		}
	else if((inputDate[2] != '/') || (inputDate[5] != '/')) /* if do not have slash '/' -- INVALID  */
		{
		printf("--- INVLAID FORMAT -- DD/MM/YYYY\n");
		}
	else 
		{
		for(i=0; (i < 10) && (bStop == 0) ; i++)
			{
			if(i == 2 || i == 5) /* do not interset '/' */
				continue;
			else if(!isdigit(inputDate[i])) /* date is digit or not */
				{
				printf("--- INVALID INPUT == ONLY NUMERIC VALUE\n");
				bStop = 0;
				}
			}
		}
	if(bStop != 0) /* if it is still correct -- bStop will be 1 -- check next condition */
		{
		sscanf(inputDate,"%d/%d/%d",&tempDay,&tempMonth,&tempYear); /* collect inputDate in format day month year */

		if(tempMonth < 1 || tempMonth > 12) /* month is less than 1 or more than 12 -- INVALID */
			{
			printf("--- INVALID DATE \n");
			bStop = 0;
			}
		else 
			{
			maxDay = monthDays[tempMonth-1]; /* collect maxDay in each month to this variable */

			if((tempMonth == 2) && (tempYear%4 == 0) && (tempYear%100 != 0)) /* if it is leap year */
				{
				maxDay = 29; /* change maxDay in February to 29 days */
				}
			if((tempDay < 1) || (tempDay > maxDay))
				{
				printf("--- INVALID DATE\n");
				bStop = 0;
				}
			if(tempYear < 2500)
				{
				printf("--- INVALID DATE\n");
				}
			}
		}

return bStop;
}
/* 
 *		dateToday function
 *		this function will collect date from local time
 *		Argument :
 *		today : collect today date
 */

void dateToday(char* today)
{
	int day;
	int month;
	int year;
    time_t seconds = 0;    
    struct tm * pTimeStruct;

    seconds = time(&seconds);
    pTimeStruct = localtime(&seconds);
    day = pTimeStruct->tm_mday;
    month = pTimeStruct->tm_mon + 1;
    year = pTimeStruct->tm_year + 2443;
    sprintf(today, "%d/%d/%d", day, month, year);
    
}

/* Compares two DATE_T structures. Returns 1 if the 
 * first date is later than the second, -1 if the 
 * first date is earlier than the second, and 0 if
 * they are the same.
 */
int dateCompare(char firstDate[],char secondDate[])
{
	int firstDay;
	int firstMonth;
	int firstYear;
	int secondDay;
	int secondMonth;
	int secondYear;
	int compareValue = 0;
	sscanf(firstDate,"%d/%d/%d",&firstDay,&firstMonth,&firstYear);
	sscanf(secondDate,"%d/%d/%d",&secondDay,&secondMonth,&secondYear);
    
    if (firstYear > secondYear)
       {
       compareValue = 1;
       }
    else if (firstYear < secondYear)
       {
       compareValue = -1;
       } 
    else if (firstMonth > secondMonth)
       {
       compareValue = 1;
       }
    else if (firstMonth < secondMonth)
       {
       compareValue = -1;
       } 
    else if (firstDay > secondDay)
       {
       compareValue = 1;
       }
    else if (firstDay < secondDay)
       {
       compareValue = -1;
       } 
    /* otherwise they are the same */

    return compareValue;
} 
/*
 *		getGender function
 *		this funtion will ask user a patient's gender
 *		if the input is invalid it will ask again
 *		Argument :
 *		gender : to get the input from user 
 *		no return
 *
 */
void getGender(char *gender)
{
	char input[128];
	char tempGender[20]; /* temporary varaible to collect gender */

	do
	{
	printf("-----------------------------------------\n");
	printf("== ENTER GENDER EX. 'M' (MALE), 'F' (FEMALE), 'N' (NOT SPECIFIED): ");
	fgets(input,sizeof(input),stdin);
	sscanf(input,"%s",tempGender);

	if(checkGender(tempGender) == 1)
		{
		strcpy(gender,"M");
		}
	else if(checkGender(tempGender) == 2)
		{
		strcpy(gender,"F");
		}
	else if(checkGender(tempGender) == 3)
		{
		strcpy(gender,"N");
		}
	else /* if input doesn't match any gender */
		{
		printf("--- INVALID INPUT -- ONLY M,F,AND N\n");
		}

	}while(checkGender(tempGender) == 0);
}
/*
 *		getName function
 *		this function will ask user a patient's name
 *		and if the name format is invalid it will ask again
 *		Argument : 
 *		name : get input from user
 *		no return
 *
 */
void getName(char* name)
{	
	char input[200];
	/* get name */
	do
	{
	printf("-----------------------------------------\n");
	printf("== ENTER PATIENT NAME: ");
	fgets(input,sizeof(input),stdin);
	}
	while(checkName(input) != 0);
	strcpy(name,input);

}


/*
 *		getBirthDate function
 *		this function will ask user a patient's birthday
 *		if a birthday is in invalid format or in future
 *		the program will print error message and ask again
 *		Argument	
 *		birthdate : get input from user
 *		no return
 *
 */
void getBirthDate(char* birthDate)
{	
	int bDate = 0; /* to use in while loop if it is not correct bDate will be 0 */
	char input[100];
	char tempDate[20]; /* to collect the input date */
	char today[11]; /* today date to use compare that inout date is in future or not */

	dateToday(today);
	while(bDate == 0)
	{
	printf("-----------------------------------------\n");
	printf("== ENTER DATE OF BIRTH (DD/MM/YYYY) BE. : ");
	fgets(input,sizeof(input),stdin);
	sscanf(input,"%s",tempDate);
	removeNewline(tempDate);
	if(strlen(tempDate) == 0)
		{
		printf("--- INVALID INPUT -- PLEASE ENTER SOME DATE\n");
		}
	else
		{
		if(checkDate(tempDate) == 1) /* if date format is still correct */
			{
			if(dateCompare(tempDate,today) != -1) /* birthdte cannot be in future */
				{
				printf("--- INVALID DATE -- DATE OF BIRTH CANNOT BE IN FUTURE\n");
				bDate = 0;
				}
			else
				{
				bDate = 1; /* birthdate is valid */
				}
			}
		else
			{
			bDate = 0;
			}
		}
	strcpy(birthDate,tempDate);	
	}	
}
/*
 *		getAdmissionDate function
 *		this function will ask user a most recently patient's admission date
 *		if admission date is in invalid format or in future
 *		the program will print error message ask again
 *		Argument	
 *		admissDate : get input from user
 *		birthDate : get birthDate to compare with admission date
 *		no return
 *
 */
void getAdmissionDate(char* admissDate,char* birthDate)
{	
	int bDate = 0; /* to use in while loop if it is not correct bDate will be 0 */
	char input[30];
	char tempDate[20]; /* to collect the input date */
	char today[11]; /* today date to use compare that inout date is in future or not */
	dateToday(today);

	do
	{
	printf("-----------------------------------------\n");
	printf("== ENTER MOST RECENT ADMISSION DATE (DD/MM/YYYY) BE. : ");
	fgets(input,sizeof(input),stdin);
	sscanf(input,"%s",tempDate);
	removeNewline(tempDate);
	if(strlen(tempDate) == 0)
		{
		printf("--- INVALID INPUT -- PLEASE ENTER SOME DATE\n");
		}
	else
		{
		if(checkDate(tempDate) == 1) /* if date format is still correct */
			{
			if(dateCompare(tempDate,today) == 1) /* admission date cannot be in future */
				{
				printf("--- INVALID DATE -- ADMISSION DATE CANNOT BE IN FUTURE\n");
				bDate = 0;
				}
			else
				{
				bDate = 1;
				}
			}
		else
			{
			bDate = 0; /* admission date is valid */
			}
		}
	
	if(bDate == 1)
		{
		strcpy(admissDate,tempDate);
		if(dateCompare(birthDate,admissDate) != -1) /* admission date must be later than birthdate */
			{
			printf("\n--- INVALID DATE -- ADMISSION DATE CANNOT BE LATER THAN BIRTH DATE\n");
			bDate = 0;
			}
		else
			{
			bDate = 1; /* admission date is valid -- can exit loop */
			}	
		}


	}while(bDate == 0);

}
/*
 *
 *		getReleaseDate function
 *		this function will ask user a most recently patient's release date
 *		if release date is in invalid format or in future
 *		the program will print error message ask again
 *		Argument	
 *		releaseDate : get input from user
 *		admissDate : get admission date to compare with release date
 *		no return
 *
 */

void getReleaseDate(char* releaseDate,char* admissDate)
{
	
	int bDate = 0;  /* to use in while loop if it is not correct bDate will be 0 */
	char input[100];
	char tempDate[20]; /* to collect the input date */
	char today[11]; /* today date to use compare that inout date is in future or not */
	dateToday(today);
	do
	{
	printf("-----------------------------------------\n");
	printf("== ENTER MOST RECENT RELEASE DATE (CAN BE BLANK IF THE PATIENT HAVE NOT RELEASED)\nDD/MM/YYYY( BE.)  : ");
	fgets(input,sizeof(input),stdin);
	memset(tempDate,0,sizeof(tempDate));
	sscanf(input,"%s",tempDate);
	removeNewline(tempDate);

	if(strlen(tempDate) == 0) /* release date can be blank */
		{
		bDate = 1; /* VALID */
		strcpy(releaseDate,tempDate);
		}
	else
		{
		if(checkDate(tempDate) == 1) /* if date format is still correct */
			{
			if(dateCompare(tempDate,today) == 1) /* release date cannot be in future */
				{
				printf("--- INVALID DATE -- RELEASE DATE CANNOT BE IN FUTURE\n");
				bDate = 0;
				}
			else
				{
				bDate = 2; /* VALID release date -- can exit loop */
				}
			}
		else
			{
			bDate = 0;
			}
		}
	
	if(bDate == 2)
		{
		strcpy(releaseDate,tempDate);
		if(dateCompare(admissDate,releaseDate) != -1)
			{
			printf("--- INVALID DATE \n");
			bDate = 0;
			}
		else
			{
			bDate = 1;
			}	
		}


	}while(bDate == 0);
}
/*
 *		getNationality function
 *		this function will ask user a patient's nationality
 *		if nationality is do not match any abbreviate nationality
 *		it will print error message and ask again
 *		Argument :
 *		nationality : get input from user
 *		no return 
 *
 */

void getNationality(char* nationality)
{
	int a =0; /* collect the return value from checkNationality function */
	char input[20];
	do
  	{
	printf("-----------------------------------------\n");
  	printf("== ENTER NATIONALITY: ");
  	fgets(input,sizeof(input),stdin);
  	a = checkNationality(input);
  	}
  	while(a != 1);
  	strcpy(nationality,input);
}

/*
 * 		getPassportId function
 *		this function will ask user a patent's passport ID
 *		if passport ID is in wrong format it will ask user again
 *		Argument : 
 *		- passpoerID : get input from the user  
 *		- nationality : get nationality to check if nationality is TH 
 *						passport ID must be 13 digits 		
 *		no return 
 *
 */
void getPassportId(char* passportID,char* nationality)
{
	char input[40]; 
	int b = 0; /* collect the return value from checkPassport function */

  	do
  	{
	printf("-----------------------------------------\n");
  	printf("== ENTER PASSPORT ID: ");
  	fgets(input,sizeof(input),stdin);
  	b = checkPassport(input,nationality);
  	}while(b != 0);
  	strcpy(passportID,input);
}
/*
 *		getHomeAddress function
 *		this function will ask user a patient's home address
 *		if home adress be blank , a program will ask again 
 *		Argument :
 *		- address : get input from the user
 *		no return
 *
 */
void getHomeAddress(char* address)
{

	char input[200];
	
	do
	{
	printf("-----------------------------------------\n");
	printf("== ENTER HOME ADDRESS \n");
	printf("EX. 197, Charoenrat Road., Watgate Sub-District, \nMueang District, ChiangMai 50000 Thailand :");
	fgets(input,sizeof(input),stdin);
	removeNewline(input);
	if(strlen(input) < 1)
	{
	printf("\n--- INVALID INPUT -- ADDRESS CANNOT BE BLANK\n");
	}
	}
	while(strlen(input) < 1);
	strcpy(address,input);

}
/*
 *		getTeleNum function
 *		this function will ask user a patient's phone number
 *		this function will check  for mat of phone number (+aaa-bbbbbb-ccccccc)
 *		if it is not in correct format, program will print error message
 *		and ask user again
 *		Argument :
 *		- phoneNumber : get input from user
 *		no return
 *
 */
void getTeleNum(char * phoneNumber)
{
    char input[64];
    int i = 0;
    int check = 0;
    int bStop = 0;
    int start = 0;


    while(bStop != 1)
    {
		printf("-----------------------------------------\n");
        printf("== ENTER PHONE NUMBER: ");
        memset(input, 0, sizeof(input));
        fgets(input, sizeof(input), stdin);
        removeNewline(input);
        if(input[0] == '+')
        {
            start = 1;
            for(i = start; i < strlen(input); i++)
            {
                if(isdigit(input[i]) != 0)
                {
                    check++;
                }
                else
                {
                    start = i;
                    break;
                }

            }

            if(input[start] == '-' && check >= 1 && check <= 3)
            {
                    check = 0;

                    for(i = start+1; i < strlen(input); i++)
                    {
                        if(isdigit(input[i]) != 0)
                        {
                            check++;
                        }
                        else
                        {
                            start = i;
                            break;
                        }
                    }
                    if(input[i] == '-' && check >= 1 && check <= 6)
                    {
                        check = 0;

                        for(i = start+1; i < strlen(input); i++)
                        {
                            if(isdigit(input[i]) != 0)
                            {
                                check++;
                            }
                            else
                            {
                                start = i;
                                break;
                            }
                        }
                        if(check == 7)
                        {
                            check = 0;
                            strcpy(phoneNumber, input);
                            bStop = 1;
                        }
                        else
                        {
                            check = 0;
                            printf("--- INVALID FORM -- +ccc-aaaaaa-bbbbbbb EX. +66-91-0200441\n");
                        }
                    }
                    else
                    {
                       check = 0;
                       printf("--- INVALID FORM -- +ccc-aaaaaa-bbbbbbb EX. +66-91-0200441\n");
                    }
            }
            else
            {
                check = 0;
                printf("--- INVALID FORM -- +ccc-aaaaaa-bbbbbbb EX. +66-91-0200441\n");
            }
        }
        else
             printf("--- INVALID FORM -- +ccc-aaaaaa-bbbbbbb EX. +66-91-0200441\n");
    }
}

/*
 *	checkRecordNumber Function
≥
 *	Argument :
 *		- input- the record number to check
 *		- patient - data of patient
 *		- header - number of data in file
 *	Return :
 *		- 0 if false
 *		- 1 if true
 *
 */
int checkRecordNumber(char *input, PATIENT_T *patient, int *header)
    {
	int i = 0;
	int count = 0;

	if(strlen(input) != 10 || input[4] != '-')
		{
		printf("INVALID FORM -- yyyy-nnnnn EX. 2557-00001\n");
		return 0;
		}
	else
		{
		for(i = 0; i < strlen(input); i++)
			{
			if(isdigit(input[i]) == 0 && i != 4)
				{
				printf("--- INVALID FORM -- yyyy-nnnnn EX. 2557-00001\n");
                return 0;
                }
            }
        }

	for(i=0; i < header[0]; i++)
        {
        if(strcmp((patient+i)->recordNum, input) == 0)
            {
            count++;
            }
		}

    if(count != 1)
        {
		printf("--- MEDICAL RECORD NUMBER NOT FOUND\n");
        return 0;
        }
    return 1;
    }

/*
 *	tolowercase Function
 *	Argument :
 *		- input- string to change to lowercase
 *		- size- sizeof that string
 */
void tolowercase(char *input, int size)
	{
	int i = 0; /* loop counter */
	for(i = 0; i < size; i++)
		{
		input[i] = tolower(input[i]);
		}
	}


