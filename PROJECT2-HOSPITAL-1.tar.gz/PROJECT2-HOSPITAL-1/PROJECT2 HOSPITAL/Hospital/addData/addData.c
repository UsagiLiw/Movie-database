/***************************************************************
 *
 * addData.c
 *
 * This program will get valid data from user
 *
 * Created by Nattawut Promsin ID : 57070503413
 * 3 December 2014
 *
 ***************************************************************
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "../MAIN/hospital.h"
#include "../validFunction/validFunction.h"
#include "../displayData/displayData.h"
#include "addData.h"

/*
 * addData
 * This function will get the data from user with valid format.
 * Argument:
 *      newData - store new data that user input
 *      header - number of last medical record number
 */
void addData(PATIENT_T *newData, int *header)
	{
	char input[MAXBUFFER];
	char date[11]; /* for store today's date */

	memset(input, 0, sizeof(input));
	printf("\e[1;1H\e[2J");
	/* ask for full name */
	getName(input);
	strcpy(newData->name, input);

    /* ask for date of birth */
	getBirthDate(input);
	strcpy(newData->birthDate, input);

	/* ask for gender */
	getGender(input);
	sscanf(input, "%c", &newData->gender);

	/* ask for nationality */
	getNationality(input);
	strcpy(newData->nationality, input);

	/* ask for passport number */
	getPassportId(input, newData->nationality);
	strcpy(newData->passport, input);

	/* ask for phone number */
	getTeleNum(input);
	strcpy(newData->phoneNum, input);

	/* ask for home address */
	getHomeAddress(input);
	strcpy(newData->address, input);

	/* ask for most recent admission date */
	getAdmissionDate(input, newData->birthDate);
	strcpy(newData->admissionDate, input);

	/* ask for most recent release date */
	getReleaseDate(input, newData->admissionDate);
	strcpy(newData->releaseDate, input);

	/* generate new medical record number */
	dateToday(date);
	sprintf(newData->recordNum, "%c%c%c%c-%05d", date[strlen(date)-4], date[strlen(date)-3], date[strlen(date)-2], date[strlen(date)-1], header[1]+1);
	}
