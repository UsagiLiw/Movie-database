/***************************************************************
 *
 * addData.h
 *
 * This header file declares function for addData.c.
 *
 * Created by Nattawut Promsin ID : 57070503413
 * 3 December 2014
 *
 ***************************************************************
 */


/*
 * addData
 * This function will get the data from user with valid format.
 * Argument:
 *      newData - store new data that user input
 *      header - number of last medical record number
 */
void addData(PATIENT_T *newData, int *header);
