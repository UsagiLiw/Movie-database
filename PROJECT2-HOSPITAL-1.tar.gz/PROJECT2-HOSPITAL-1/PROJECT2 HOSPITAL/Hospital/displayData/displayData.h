/***************************************************************
 *
 * displayData.h
 *
 * This header file declares function for displayData.c.
 *
 * Created by Karn Watthanatraiphob ID : 57070503402
 * 3 December 2014
 *
 ***************************************************************
 */

/*
 * displayEach
 * This function will display one data of patient
 * Argument :
 *      patient - data of patient
 *      which - the index points which patient will display
 */
void displayEach(PATIENT_T *dataPatient, int which);

/*
 * displayData
 * This function will display all data
 * Argument :
 *      patient - data of patient
 *      header - number of data
 */
void displayData(PATIENT_T *patient, int *header);
