/***************************************************************
 *
 * displayData.c
 *
 * This program will display data from file.
 *
 * Created by Karn Watthanatraiphob ID : 57070503402
 * 3 December 2014
 *
 ***************************************************************
 */
#include <stdio.h>

#include "../MAIN/hospital.h"
#include "displayData.h"

/*
 * displayEach
 * This function will display one data of patient
 * Argument :
 *      patient - data of patient
 *      which - the index points which patient will display
 */
void displayEach(PATIENT_T *patient, int which)
	{
	printf("\n==========================================================\n");
	printf("==== Medical record number        : %s\n", patient[which].recordNum);
	printf("==== Full name                    : %s\n", patient[which].name);
	printf("==== Date of birth                : %s\n", patient[which].birthDate);
	printf("==== Gender                       : %c\n", patient[which].gender);
	printf("==== Nationality                  : %s\n", patient[which].nationality);
	printf("==== Passport number              : %s\n", patient[which].passport);
	printf("==== Phone number                 : %s\n", patient[which].phoneNum);
	printf("==== Address                      : %s\n", patient[which].address);
	printf("==== Most recent admission date   : %s\n", patient[which].admissionDate);
	printf("==== Most recent release date     : %s\n", patient[which].releaseDate);
	printf("==========================================================\n");
	}

/*
 * displayData
 * This function will display all data
 * Argument :
 *      patient - data of patient
 *      header - number of data
 */
void displayData(PATIENT_T *patient, int *header)
	{
	int i = 0; /* index */
    /* clear screen */
	printf("\e[1;1H\e[2J");
	/* display all data */
	for(i = 0; i < header[0]; i++)
		{
		displayEach(patient, i);
		}
	printf("==== There are %d record(s) in database.\n\n", header[0]);
	}
