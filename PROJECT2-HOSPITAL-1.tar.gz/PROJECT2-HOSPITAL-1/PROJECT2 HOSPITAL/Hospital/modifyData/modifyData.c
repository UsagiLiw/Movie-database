/***************************************************************
 *
 * modifyData.c
 *
 * This program will update all data of patient
 *
 * Created by Thanchanok Eiamsakulchai ID : 57070503416
 * 3 December 2014
 *
 ***************************************************************
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "../MAIN/hospital.h"
#include "../displayData/displayData.h"
#include "../validFunction/validFunction.h"
#include "modifyData.h"

/*
 * confirm
 * This function will confirm for update data
 * Argument:
 *      choice - store choice from user
 *      which - type of data
 */
void confirm(char *choice, int which)
	{
	char input[MAXBUFFER];
	char *data[] =
		{
		"Full name",
		"Date of birth",
		"Gender",
		"Nationality",
		"Passport number",
		"Phone number",
		"Address",
		"Most recent admission date",
		"Most recent release date"
		};

	do
        {
        printf("==== Do you want to update %s? (y/n): ", data[which]);
        fgets(input,sizeof(input),stdin);
		removeNewline(input);
        input[0] = tolower(input[0]);
        }while(strlen(input) != 1 || (input[0] != 'y' && input[0] !='n'));
    sscanf(input, "%s", choice);
	}

/*
 * modifyData
 * This function for updating the data.
 * Argument :
 *      patient - data of patient
 *      header - number of data
 *      position - position of data
 */
void modifyData(PATIENT_T *patient,int *header, int position)
	{
	char input[MAXBUFFER];
	char choice = '\0';

	confirm(&choice, 0);
	if(choice == 'y')
	  	{
		getName(input);
		strcpy((patient+position)->name, input);
		}
	confirm(&choice, 1);
	if(choice == 'y')
	  	{
		getBirthDate(input);
		strcpy((patient+position)->birthDate, input);
		}
	confirm(&choice, 2);
	if(choice == 'y')
	   	{
		getGender(input);
		sscanf(input, "%c", &(patient+position)->gender);
		}
	confirm(&choice, 3);
	if(choice == 'y')
	  	{
		getNationality(input);
		strcpy((patient+position)->nationality, input);
		}
	confirm(&choice, 4);
	if(choice == 'y')
	   	{
		getPassportId(input, (patient+position)->nationality);
		strcpy((patient+position)->passport, input);
		}
	confirm(&choice, 5);
	if(choice == 'y')
	   	{
		getTeleNum(input);
		strcpy((patient+position)->phoneNum, input);
		}
	confirm(&choice, 6);
	if(choice == 'y')
	   	{
		getHomeAddress(input);
		strcpy((patient+position)->address, input);
		}
	confirm(&choice, 7);
	if(choice == 'y')
	   	{
		getAdmissionDate(input, (patient+position)->birthDate);
		strcpy((patient+position)->admissionDate, input);
		}
	confirm(&choice, 8);
	if(choice == 'y')
	   	{
		getReleaseDate(input, (patient+position)->admissionDate);
		strcpy((patient+position)->releaseDate, input);
		}
		displayEach(patient, position);
		printf("UPDATE DONE.\n\n");
	}
