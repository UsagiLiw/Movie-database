/***************************************************************
 *
 * modifyData.h
 *
 * This header file declares function for modifyData.h
 *
 * Created by Thanchanok Eiamsakulchai ID : 57070503416
 * 3 December 2014
 *
 ***************************************************************
 */

/*
 * confirm
 * This function will confirm for update data
 * Argument:
 *      choice - store choice from user
 *      which - type of data
 */
void confirm(char *choice, int which);

/*
 * modifyData
 * This function for updating the data.
 * Argument :
 *      patient - data of patient
 *      header - number of data
 *      position - position of data
 */
void modifyData(PATIENT_T *patient,int *header, int position);
