/***************************************************************
 *
 * dumpData.c
 *
 * This program will dump all data in database.
 *
 * Created by Karn Watthanatraiphob ID : 57070503402
 * 3 December 2014
 *
 ***************************************************************
 */

#include <stdio.h>
#include <stdlib.h>

#include "../MAIN/hospital.h"
#include "dumpData.h"

/*
 * dumpData
 * This function will write data to text file.
 * Argument:
 *      patient - data of patient
 *      header - number of data
 */
void dumpData(PATIENT_T *patient, int *header)
	{
	int i = 0; /* index */
	FILE *pOutfile = NULL;

	printf("\e[1;1H\e[2J");
	pOutfile = fopen(DUMPFILE, "w");
	if(pOutfile == NULL)
		{
		printf("Error in writing dumpfile!\n");
		exit(0);
		}

	fprintf(pOutfile, "%d %d\n", header[0], header[1]);
	for(i = 0; i < header[0]; i++)
		{
		fprintf(pOutfile, "[%s] [%s] [%s] [%c] [%s] [%s] [%s] [%s] [%s] [%s]\n", patient[i].recordNum, patient[i].name, patient[i].birthDate, patient[i].gender, patient[i].nationality, patient[i].passport, patient[i].phoneNum, patient[i].address, patient[i].admissionDate, patient[i].releaseDate);
		}
	fclose(pOutfile);
	printf("==== DUMPFILE has been created.\n");
	}
