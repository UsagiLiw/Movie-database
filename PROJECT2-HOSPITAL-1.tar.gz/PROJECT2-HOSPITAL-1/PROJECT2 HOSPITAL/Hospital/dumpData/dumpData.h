/***************************************************************
 *
 * dumpData.h
 *
 * This header file declares function for dumpData.c
 *
 * Created by Karn Watthanatraiphob ID : 57070503402
 * 3 December 2014
 *
 ***************************************************************
 */


#define DUMPFILE "DUMPFILE.txt" /* name of dump file */

/*
 * dumpData
 * This function will write data to text file.
 * Argument:
 *      patient - data of patient
 *      header - number of data
 */
void dumpData(PATIENT_T *patient, int *header);
