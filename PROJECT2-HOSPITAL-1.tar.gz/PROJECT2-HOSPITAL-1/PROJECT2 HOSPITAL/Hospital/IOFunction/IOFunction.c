/***************************************************************
 *
 * IOFunction.c
 *
 * This program include reading and writing database file.
 *
 * Created by Woraphop Kootranunt ID : 57070503430
 * 3 December 2014
 *
 ***************************************************************
 */

#include <stdio.h>
#include <stdlib.h>

#include "../MAIN/hospital.h"
#include "IOFunction.h"


/*
 * readHeader
 * This function will read header file
 * Argument:
 *      header - store header file(number of data)
 */
void readHeader(int *header)
	{
	FILE* pInfile = NULL; /* file pointer for input file */
    /* open input file */
	pInfile = fopen(DATABASE, "rb");
	/* print error and exit when cannot open file */
	if(pInfile == NULL)
		{
		printf("Cannot open database file!\n");
		exit(0);
		}
    /* print error and exit when cannot read header file */
	if(fread(header, sizeof(int), 2, pInfile) != 2)
		{
		printf("Cannot read file!\n");
		exit(1);
		}
	fclose(pInfile);
	}

/*
 * readData
 * This function will read data from binary file
 * Argument:
 *      patient - store data
 *      header - number of data
 */
void readData(PATIENT_T *patient, int *header)
	{
	FILE *pInfile = NULL; /* file pointer for input file */
    /* open input file */
	pInfile = fopen(DATABASE, "rb");
	/* print error and exit when cannot open file */
	if(pInfile == NULL)
		{
		printf("Cannot open database file!\n");
		exit(0);
		}
    /* print error and exit when cannot read header file */
	if(fread(header, sizeof(int), 2, pInfile) != 2)
		{
		printf("Cannot read file!\n");
		exit(1);
		}
    /* print error and exit when cannot read data */
	if(fread(patient, sizeof(PATIENT_T), header[0], pInfile) != header[0])
		{
		printf("Cannot read file!\n");
		exit(2);
		}
	fclose(pInfile);
	}

/*
 * writeData
 * This function will write data to binary file
 * Argument:
 *      patient - data to write
 *      header - number of data
 */
void writeData(PATIENT_T *patient, int *header)
	{
	FILE *pOutfile = NULL; /* file pointer for output file */
    /* open output file */
	pOutfile = fopen(DATABASE, "wb");
    /* print error and exit when cannot open file */
	if(pOutfile == NULL)
		{
		printf("Cannot open database file!\n");
		exit(0);
		}
    /* print error and exit when cannot write header file */
	if(fwrite(header, sizeof(int), 2, pOutfile) != 2)
		{
		printf("Error in writing!\n");
		exit(1);
		}
    /* print error and exit when cannot write data */
	if(fwrite(patient, sizeof(PATIENT_T), header[0], pOutfile) != header[0])
		{
		printf("Error in writing!\n");
		exit(2);
		}
	fclose(pOutfile);
	}







