/***************************************************************
 *
 * IOFunction.h
 *
 * This header file declares the function for IOFunction.c
 *
 * Created by Woraphop Kootranunt ID : 57070503430
 * 3 December 2014
 *
 ***************************************************************
 */

#define DATABASE "DATABASE.dat" /* name of database */

/*
 * readHeader
 * This function will read header file
 * Argument:
 *      header - store header file(number of data)
 */
void readHeader(int *header);

/*
 * readData
 * This function will read data from binary file
 * Argument:
 *      patient - store data
 *      header - number of data
 */
void readData(PATIENT_T *patient, int *header);

/*
 * writeData
 * This function will write data to binary file
 * Argument:
 *      patient - data to write
 *      header - number of data
 */
void writeData(PATIENT_T *patient, int *header);
