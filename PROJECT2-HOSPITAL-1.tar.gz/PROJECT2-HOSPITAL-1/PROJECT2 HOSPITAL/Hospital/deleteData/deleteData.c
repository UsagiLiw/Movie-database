/***************************************************************
 *
 * deleteData.c
 *
 * This program will delete data out of database
 *
 * Created by Thanchanok Eiamsakulchai ID : 57070503416
 * 3 December 2014
 *
 ***************************************************************
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "../MAIN/hospital.h"
#include "deleteData.h"

/*
 * deleteData
 * This function will delete data out of database
 * Argument :
 *      patient - data of patient
 *      header - number of data
 *      position - position of data
 */
void deleteData(PATIENT_T *patient, int *header, int position)
	{
	int i = 0; /* index */

    /* move up the data one space */
	for(i = position; i < header[0]-1; i++)
		{
		memcpy((patient+i), (patient+i+1), sizeof(PATIENT_T));
		}
    /* delete the last position */
	if(i == header[0]-1)
		{
		memset((patient+i), 0, sizeof(PATIENT_T));
		}
    /* reallocate memory that decreased by one */
	patient = (PATIENT_T*) realloc(patient, sizeof(PATIENT_T)*(header[0]-1));
	if(patient == NULL)
		{
		printf("Cannnot allocate memories!\n");
		free(patient);
		patient = NULL;
		exit (1);
		}
	else
		{
		header[0] -= 1;
		printf("==== DELETE DONE.\n");
		}
	}
