/***************************************************************
 *
 * deleteData.h
 *
 * This header file declares function for deleteData.c
 *
 * Created by Thanchanok Eiamsakulchai ID : 57070503416
 * 3 December 2014
 *
 ***************************************************************
 */


/*
 * deleteData
 * This function will delete data out of database
 * Argument :
 *      patient - data of patient
 *      header - number of data
 *      position - position of data
 */
void deleteData(PATIENT_T *patient, int *header, int position);
