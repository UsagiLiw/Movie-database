/***************************************************************
 *
 * hospital.c
 *
 * This program is main function of Hospital Information System.
 * The database will store information about patient in hospital.
 *
 * Created by Wasunan Rojkanok ID : 57070503432
 * 3 December 2014
 *
 ***************************************************************
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "hospital.h"
#include "../IOFunction/IOFunction.h"
#include "../displayData/displayData.h"
#include "../searchData/searchData.h"
#include "../validFunction/validFunction.h"
#include "../dumpData/dumpData.h"
#include "../addData/addData.h"

/*
 * displayMenu
 * This function will display main menu of the program.
 */
void displayMenu()
	{
	printf("===============================================\n");
	printf("================ Main Menu ====================\n");
	printf("===============================================\n");
	printf("====	1 - Display data                  =====\n");
	printf("====	2 - Add data                      =====\n");
	printf("====	3 - Find data                     =====\n");
	printf("====	4 - Dump data                     =====\n");
	printf("====	0 - Exit                          =====\n");
	printf("===============================================\n");
	printf("= Enter your choice: ");
	}

/*
 * Main function
 * Display menu and get choice from user
 */
int main()
	{
	char input[MAXBUFFER]; /* buffer */
	int choice = 0; /* to get choice from user */
	int header[2] = {0,0}; /* to store number of data and last medical record number */
	PATIENT_T *patient = NULL; /* to store data of all patient */
	PATIENT_T newData; /* to store new data that user input */

	/* read header file */
    readHeader(header);

	/* allocate memories */
    patient = (PATIENT_T*) calloc(header[0], sizeof(PATIENT_T));
	if(patient == NULL)
		{
		printf("Cannnot allocate memories!\n");
		exit (1);
		}

	/* read data from DATABASE.dat */
	readData(patient, header);

	do
		{
        /* clear screen */
		printf("\e[1;1H\e[2J");
		/* display menu */
		displayMenu();
		/* get choice */
		fgets(input, sizeof(input), stdin);
		if(strlen(input) == 2 || isdigit(input[0]) != 0)
			{
			sscanf(input, "%d", &choice);
			/* display all data */
			if(choice == 1)
				{
                /* call function to display data */
				displayData(patient, header);
				printf("PRESS ENTER TO CONTINUE.\n");
				getchar();
				}
			/* add data */
			else if(choice == 2)
				{
				memset(input, 0, sizeof(input));
				do
					{
					printf("==========================================================\n");
					printf("==== Do you want to add data? (y/n): ");
					fgets(input,sizeof(input),stdin);
					removeNewline(input);
					input[0] = tolower(input[0]);
					}while(strlen(input) != 1 || (input[0] != 'y' && input[0] !='n'));
				if(input[0] == 'y')
					{
					memset(&newData, 0, sizeof(newData));
                    /* call function to add data*/
					addData(&newData, header);
                    /* reallocate memory for hold 1 more data */
					patient = (PATIENT_T*) realloc(patient, sizeof(PATIENT_T)*(header[0]+1));
                    /* if reallocate unsuccessfully */
					if(patient == NULL)
						{
						printf("Cannnot allocate memories!\n");
						/* release dynamically allocated memory then exit */
						free(patient);
						patient = NULL;
						exit (1);
						}
                    /* if reallocate successfully */
					else
						{
                        /* copy new data into new allocate */
						memcpy(&patient[header[0]], &newData, sizeof(PATIENT_T));
						/* call function to display data of new patient */
						displayEach(patient, header[0]);
						header[0] += 1;
						header[1] += 1;
						printf("==== ADD DATA DONE.\n");
						printf("PRESS ENTER TO CONTINUE.\n");
						getchar();
						}
					}
				}
			/* find data */
			else if(choice == 3)
				{
                /* call function to search */
				searchData(patient, header);
				printf("PRESS ENTER TO CONTINUE.\n");
				getchar();
				}
			/* dump data */
			else if(choice == 4)
				{
                /* call function to dump data */
				dumpData(patient, header);
				printf("PRESS ENTER TO CONTINUE.\n");
				getchar();
				}
			}
		}while(atoi(input) != 0 || isdigit(input[0]) == 0);

    /* if user exit, ask user to confirm about save all changes to database */
	if(choice == 0)
		{
		memset(input, 0, sizeof(input));
		do
			{
			printf("==========================================================\n");
			printf("==== Do you want to save your changes to DATABASE? (y/n): ");
			fgets(input,sizeof(input),stdin);
			removeNewline(input);
			input[0] = tolower(input[0]);
			}while(strlen(input) != 1 || (input[0] != 'y' && input[0] !='n'));
		/* if user want to save all changes to database */
		if(input[0] == 'y')
			{
            /* call function to write database */
			writeData(patient, header);
			printf("==== All your changes have been saved.\n");
			}
        /* release dynamically allocated memory */
		free(patient);
		patient = NULL;
		}
	return 0;
	}
