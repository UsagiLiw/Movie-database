/***************************************************************
 *
 * hospital.h
 *
 * This header file declares the structure for program.
 *
 * Created by Wasunan Rojkanok ID : 57070503432
 * 3 December 2014
 *
 ***************************************************************
 */

#define MAXBUFFER 128 /* Maximum buffer */

typedef struct
	{
	char recordNum[11]; /* The medical record number (format yyyy-nnnnn) */
    char name[MAXBUFFER]; /* Full name of the patient */
	char birthDate[11]; /* Date of birith (format dd/mm/yyyy) */
	char gender; /* M if male, F if female, N if prefer not to specify */
	char nationality[3]; /* Nationality of the patient (two letter abbreviation) */
	char passport[16]; /* Passport number (13 digits for TH, 8-16 for the others */
	char phoneNum[20]; /* Phone number of the patient (format +ccc-aaaaa-nnnnnnnn) */
	char address[MAXBUFFER]; /* Home address of the patient */
	char admissionDate[11]; /* Most recent admission date */
	char releaseDate[11]; /* Most recent release date */
	} PATIENT_T;




